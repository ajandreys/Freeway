function setup() {
  createCanvas(500, 400);
  somDaTrilha.loop();
}

function draw() {
  background(imagemDaEstrada);
  //cor da imagem, caso queira que apareça uma imagem mesmo, inserir a variável entre os parênteses
  mostraAtor();
  mostraCarro();
  movimentaCarro();
  movimentaAtor();
  voltaPosicaoInicialDoCarro();
  verificaColisao();
  mostraMeusPontos();
  marcaPontos();
}

