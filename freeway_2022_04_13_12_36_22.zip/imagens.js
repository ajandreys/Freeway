//código imagens e sons

let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;

let somDaTrilha;
let somDaColisao;
//let somDoPonto;

function preload(){
  imagemDaEstrada = loadImage("IMagens/estrada.png");
  imagemDoAtor = loadImage("IMagens/ator-1.png");
  imagemCarro = loadImage("IMagens/carro-1.png");
  imagemCarro2 = loadImage("IMagens/carro-2.png");
  imagemCarro3 = loadImage("IMagens/carro-3.png");
  imagemCarros = [imagemCarro, imagemCarro2, imagemCarro3, imagemCarro, imagemCarro2, imagemCarro3];
  
  somDaTrilha = loadSound("Sons/trilha.mp3");
  somDaColisao = loadSound("Sons/colidiu.mp3");
  somDoPonto = loadSound("Sons/pontos.wav");
}
//indicar qual o caminho para chegar na imagem, por exemplo, ela está dentro da pasta imagens e atende pelo nome de estrada.png