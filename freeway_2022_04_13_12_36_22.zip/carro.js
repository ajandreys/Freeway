//código do carro

let xCarros = [600, 600, 500, 600, 500, 600];
let yCarros = [40, 100, 210, 150, 270, 315];
let velocidadeCarros = [2, 2.5, 3.2, 1, 2.7, 10];
let comprimentoCarro = 45;
let alturaCarro = 38;

function mostraCarro () {
  for (let i = 0; i < imagemCarros.length; i += 1) {
    image(imagemCarros [i], xCarros [i], yCarros [i], comprimentoCarro, alturaCarro);
    }
}

function movimentaCarro() {
  //xCarro = xCarro - 2; ou
  for (i = 0; i < imagemCarros.length; i = i + 1) {
    xCarros[i] -= velocidadeCarros[i];
  }
  //print(xCarro); mostra posição no console
}

function voltaPosicaoInicialDoCarro () {
  for (i = 0; i < imagemCarros.length; i++) {
    if (passouTodaTela(xCarros[i])) {
    xCarros [i] = 600;
    }
  }
}

function passouTodaTela (xCarro) {
  return xCarro < - 50;
}

 
