//código do ator
let xAtor = 100;
let yAtor = 370;

//variáveis colisão
let colisao = false;

// variáveis pontos
let meusPontos = 0;

function mostraAtor () {
  image(imagemDoAtor, xAtor, yAtor, 30, 30); // parâmetros: imagem, x, y, altura, comprimento
  //print(yAtor);
}

function movimentaAtor() {
  if (keyIsDown(UP_ARROW)) {
    yAtor -= 3;
  }
  if (keyIsDown(DOWN_ARROW)) {
    if(podeMover()) {
      yAtor += 3;
    }
  }
}

//limitação do movimento do personagem
function podeMover() {
  return yAtor < 370;
}

function verificaColisao() {
  //collideRectCircle(x1, y1, width1, height1, cx, cy, diameter)
  for (let i = 0; i < imagemCarros.length; i = i + 1) {
    colisao = collideRectCircle(xCarros[i], yCarros[i], comprimentoCarro, alturaCarro, xAtor, yAtor, 20);
    if (colisao) {
      voltaAtorPosicaoInicial();
      somDaColisao.play();
      if (meusPontos > 0) {
        meusPontos -= 1;
      }
    }
  }
}

function voltaAtorPosicaoInicial() {
  yAtor = 370;
}

function mostraMeusPontos() {
  textAlign(CENTER);
  textSize(25);
  textFont("Verdana");
  fill(color(255,105,180));
  text(meusPontos, width / 2, 25);
}

function marcaPontos() {
  if (yAtor < 9) {
    meusPontos += 1;
    somDoPonto.play();
    voltaAtorPosicaoInicial();
  }
}